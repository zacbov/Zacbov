# Inky Bird Frame — version « écoute + sonagramme »

Un cadre e-ink qui affiche le **dernier oiseau entendu** chez toi et le
**sonagramme** (spectrogramme) de son chant.

Contrairement à l'Inky Bird Frame d'origine (qui lit des observations publiques),
ici c'est un **vrai capteur audio** : un micro écoute, **BirdNET-Go** identifie
l'espèce, et un écran e-ink montre le résultat.

## Architecture

```
   micro USB
      │
      ▼
┌───────────────────────── Raspberry Pi 3B+ ─────────────────────────┐
│  BirdNET-Go  ──►  base SQLite + clips audio                        │
│        │                                                          │
│        ▼                                                          │
│  server.py  ── lit la dernière détection (birdnet_db.py)          │
│        │     ── calcule le sonagramme du clip (spectrogram.py)    │
│        │     ── compose l'image 800x480 1-bit (render.py)         │
│        ▼                                                          │
│  HTTP :8090/frame.bin  (48000 octets prêts à afficher)           │
└───────────────────────────────┬───────────────────────────────────┘
                                 │ WiFi
                                 ▼
                         ESP32 (afficheur)
                                 │ SPI
                                 ▼
                Waveshare 7.5" e-Paper V2 (UC8179)
```

Idée clé : **tout le cerveau est sur le Pi**. L'ESP32 ne fait que télécharger une
image déjà prête et la coller → firmware minuscule, design modifiable sans jamais
reflasher l'ESP32.

## Contenu

| Fichier | Rôle |
|---|---|
| `SETUP_PI.md` | **tutoriel d'installation** pas à pas (à suivre le moment venu) |
| `config.ini` | chemins + clés (non versionné) |
| `birdnet_db.py` | lit la dernière détection dans la base BirdNET-Go (schéma auto-détecté) |
| `inspect_db.py` | diagnostic du schéma de la base |
| `spectrogram.py` | clip audio → image de sonagramme (repli ffmpeg pour le mp3) |
| `xenocanto.py` | chant de **référence** propre par espèce (API xeno-canto v3, cache) |
| `render.py` | composition du cadre 800×480 + empaquetage 1-bit |
| `server.py` | sert `/frame.bin` à l'ESP32 (+ `/frame.png`, `/latest.json`) |
| `frame.service` | démarrage auto du serveur (systemd) |
| `esp32/` | firmware Arduino + guide de câblage/flash |

## Démarrage rapide (une fois le Pi prêt)

1. Suis `SETUP_PI.md` partie A → BirdNET-Go écoute.
2. Partie B → `python server.py`, puis ouvre `http://birdpi.local:8090/`.
3. `esp32/README_ESP32.md` → flashe l'ESP32 avec l'IP du Pi.

## Chant de référence xeno-canto (fait ✓)

Quand la capture de jardin est absente ou trop bruitée, le cadre affiche le
sonagramme d'un enregistrement de **référence** de l'espèce, avec crédit du
contributeur.

- Colle ta clé API v3 dans `[xenocanto] api_key` de `config.ini` (hors dépôt).
- `use_reference` : `fallback` (défaut, référence seulement si pas de clip local),
  `always` (toujours le chant "type"), ou `never`.
- Le **réseau se fait en tâche de fond** sur le Pi (préchargement dès qu'une
  nouvelle espèce est détectée) ; le chemin qui sert l'ESP32 ne lit que le cache.
- Test manuel : `python xenocanto.py "Erithacus rubecula"`.

## Idées suivantes (pas urgent)

- Vignette illustrée (planche naturaliste du domaine public via Wikimedia) à côté
  du sonagramme.
- Petit historique des dernières espèces du jour.
```
